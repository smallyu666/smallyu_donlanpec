from PyQt5.QtWidgets import QItemDelegate
from PyQt5.QtGui import QColor
from PyQt5.QtCore import QRect, Qt, QEvent

class DesignDataDelegate(QItemDelegate):
    """自定义代理，为"设计压力*"单元格添加多工况标识，并响应点击"""

    def paint(self, painter, option, index):
        super().paint(painter, option, index)

        if index.column() == 1:  # 参数名称列
            cell_text = index.data(Qt.DisplayRole)
            if isinstance(cell_text, str) and "设计压力*" in cell_text:
                painter.save()
                
                # ✅ 根据是否有工况2/3数据决定颜色
                has_data = False
                if hasattr(option.widget, "viewer"):
                    viewer = option.widget.viewer
                    if hasattr(viewer, "_has_multi_conditions"):
                        has_data = viewer._has_multi_conditions
                
                # 有数据：深色（深蓝色），无数据：浅色（浅灰色）
                if has_data:
                    bg_color = QColor(190, 190, 190)  # 浅灰h背景
                    text_color = QColor(0, 0, 0)  # 黑色
                    border_color = QColor(200, 200, 200)
                else:
                    # 无数据
                    bg_color = None
                    text_color = QColor(150, 150, 150)  # 浅灰色（原色）
                    border_color = QColor(200, 200, 200)  # 浅灰色边框（原色）
                
                font = painter.font()
                font.setBold(False)
                font.setPointSize(8)
                painter.setFont(font)

                rect = option.rect
                # ✅ 保持和 paint 一致：靠右 80px 宽
                self._badge_rect = QRect(rect.right() - 85, rect.top() + 2, 80, rect.height() - 4)

                # ✅ 先画背景（只在有数据时）
                if bg_color is not None:
                    painter.fillRect(self._badge_rect.adjusted(1, 1, -1, -1), bg_color)

                # 再画文字和边框
                painter.setPen(text_color)
                painter.drawText(self._badge_rect, Qt.AlignCenter, "多工况...")
                painter.setPen(border_color)
                painter.drawRect(self._badge_rect.adjusted(1, 1, -1, -1))
                painter.restore()

    def editorEvent(self, event, model, option, index):
        if event.type() == QEvent.MouseButtonRelease and index.column() == 1:
            cell_text = index.data(Qt.DisplayRole)
            if isinstance(cell_text, str) and "设计压力*" in cell_text:
                rect = QRect(option.rect.right() - 85, option.rect.top() + 2, 80, option.rect.height() - 4)
                if rect.contains(event.pos()):  # ✅ 仅点击标识框触发
                    print("[多工况] 点击了多工况标识")
                    # 找到 viewer 调用弹窗
                    if hasattr(option.widget, "viewer"):
                        option.widget.viewer._open_multi_conditions_dialog(index.row(), index.column(), "壳程/管程")
                    return True
        return super().editorEvent(event, model, option, index)
